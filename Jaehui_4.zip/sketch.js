let i = 0;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  noStroke();
}

function draw() {
  background(80, 188, 223);
  fill(255, 127, 0, 0.3);
  ellipse(200, 200, 80, 80);
  fill(155, 17, 30, 1);
  ellipse(200, 200, 50, 50); //sun
  
  for (let i = 0; i < 400; i = i + 90) {
    fill(155, 72, 0, 1);
    rect(i, 380, 50, 20);
  }
  
  ellipseMode(CENTER);
  translate(width / 20, height / 20);
  translate(p5.Vector.fromAngle(millis() / 1000, 40));  
  
  fill(255, 255, 255, 1);
  ellipse(0, 80, 200, 30);
  ellipse(0, 60, 100, 50);
  scale(0.5)
  ellipse(80, 320, 200, 30);
  ellipse(80, 300, 100, 50);
  ellipse(400, 180, 200, 30);
  ellipse(400, 160, 100, 50); //clouds
  
  
  
  
  
}